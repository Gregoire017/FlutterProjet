import 'package:flutter/material.dart';
import 'page1.dart';
import 'main.dart';

class Page2 extends StatelessWidget {
   @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButton: FloatingActionButton(onPressed: () {
          Navigator.push(
              context, new MaterialPageRoute(builder: (context) => Page1()));
        }),
        body: Container(
          child: Center(
            child: Text('Page 15'),
          ),
        ));
  }
}