import 'package:flutter/material.dart';
import 'page2.dart';
import 'dart:io';
import 'package:flutter/foundation.dart';

class Page1 extends StatelessWidget {
  @override
   Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Noolibee',
        home: Scaffold(
            resizeToAvoidBottomInset: false,
            appBar: AppBar(
            
              title: Center(
                child: Text(
                  "Log Viewer",
                  
                ),
              ),
            ),
            body: Container(
              padding:
                  EdgeInsets.only(top: 30, bottom: 30, left: 10, right: 10),
              child: Column(
                children: <Widget>[
                  Expanded(
                      child: ListView.builder(
                          itemBuilder: (BuildContext context, int index) {
                            return Container(
                              margin: EdgeInsets.only(
                                  top: 10, bottom: 10, left: 20, right: 20),
                              padding: EdgeInsets.all(10),
                              height: 100,
                              decoration: BoxDecoration(
                              ),
                              child: Row(
                                children: <Widget>[
                                ],
                              ),
                            );
                          })),
                  Container(
                    margin: EdgeInsets.only(top: 20),
                    child: FlatButton(
                      padding: EdgeInsets.all(15),
                      //splashColor: Colors.white,
                      onPressed: () {
                       Navigator.push(
            context, new MaterialPageRoute(builder: (context) => Page2()));// j'envoie vers
            // Mqtt.dart
                      },
                      child: Text(
                        "Clean",
                      ),
                    ),
                  ),
                ],
              ),
            )));
  }
}

/*margin: EdgeInsets.only(top: 20),
                    child: FlatButton(
                      color: color2,
                      textColor: color1,
                      padding: EdgeInsets.all(15),
                      //splashColor: Colors.white,
                      onPressed: () {
                        Navigator.push(context,new MaterialPageRoute
                        (builder: (BuildContext context) {
                          return MQTT();
                        }),
                        );
                      },
                      child: Text(
                        "Clean",
                      ),
                    ),


  floatingActionButton: FloatingActionButton(onPressed: () {
          Navigator.push(
              context, new MaterialPageRoute(builder: (context) => Page2()));
        }),
        
        body: Container(
          child: Center(
            child: Text('Page 1'),
          ),
        ));*/
