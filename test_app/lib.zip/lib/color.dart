import 'package:flutter/cupertino.dart';

Color color1 = new Color(0xFF6D1B42);
Color color2 = new Color(0xFFF5853F);